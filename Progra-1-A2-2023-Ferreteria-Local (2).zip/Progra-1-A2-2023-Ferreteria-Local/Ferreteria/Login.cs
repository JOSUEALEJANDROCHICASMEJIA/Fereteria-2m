﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ferreteria
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((txtUsuario.Text == "" && txtContraseña.Text == "")) ;
            {
                if ((txtUsuario.Text == "admin" && txtContraseña.Text == "Contraseña")) ;
                {
                    Form1 formulairo = new Form1();
                    Form1.Show();
                    this.Hide();
                }
            }
        }
    }
    }

